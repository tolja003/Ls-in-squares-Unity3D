using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class Shrink : MonoBehaviour
{
    public float start, end,speed;
    public bool On = false;
    public float epsilon = 0.001f;
    public UnityEvent OnFinish;

    // Start is called before the first frame update
    void Start()
    {
        Init();
        
    }
    public void Init()
    {
        transform.localScale = new Vector3(start, transform.localScale.y, start);
    }

    // Update is called once per frame
    void Update()
    {   if (On)
        {
            transform.localScale = Vector3.Lerp(transform.localScale, new Vector3(end, transform.localScale.y, end), speed * Time.deltaTime);
            if(Mathf.Abs(transform.localScale.x - end)<epsilon)
            {
                On = false;
                OnFinish.Invoke();
            }
        }
    }
}
