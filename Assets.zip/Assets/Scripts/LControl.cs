using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LControl : MonoBehaviour
{
    public float height = 0;
    

    public float Mod = 45f;
    public float delta = 0.005f;
    public float speed = 1;
    // Start is called before the first frame update
    void Start()
    {
        
    }
    float fix(float y)
    {

        if (y < 0) y += 360;
        float less = 0;
        while (less < y) less += Mod;
        if (less > y) less -= Mod;
        float up = less;
        while (up < y) up += Mod;
        if (y - less < up - y) return less;
        return up;

    }
    void FixMe()
    {
        float y = transform.rotation.eulerAngles.y;
        float s1 = y - fix(y);
        //float s2=-y-fix(-y);
        //print(s1);
        //print(s2);
        //if(Mathf.Abs(s1)<Mathf.Abs(s2)){
        transform.Rotate(new Vector3(0, 1, 0), -speed * s1 * Time.deltaTime);
        //}
        //else{
        //transform.Rotate(new Vector3(0,1,0),-delta*s2*Time.deltaTime);
        //	}
        //print(fix(transform.rotation.eulerAngles.y).ToString()+" "+transform.rotation.eulerAngles.y.ToString());

    }

    // Update is called once per frame
    void FixedUpdate()
    {
        FixMe();
        if (Mathf.Abs(height-transform.position.y)<delta)
        {
            gameObject.GetComponent<Rigidbody>().constraints |= RigidbodyConstraints.FreezePositionY;
        }
    }
}
