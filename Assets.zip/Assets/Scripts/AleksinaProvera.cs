using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AleksinaProvera: MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }

    public static bool IsOk(List<Transform> Ls, double kvadrat)
    {
        List<Figurica> a = new List<Figurica>();

        foreach (Transform L in Ls)
        {
            Tacka T;
            T.x = (double) L.position.x;
            T.y = (double) L.position.z;

            Figurica F;
            F.teziste = T;
            F.angle = (double) Mathf.Deg2Rad * (-L.eulerAngles.y+45);
            a.Add(F);
            if (prelaziGranicu(kvadrat, F))
            {
             
                return false;
            }
        }

      //  List<string> z = new List<string>();
      

        for (int i = 0; i < a.Count; i++)
            for (int j = i + 1; j < a.Count; j++)
            {
                if (presekFigurica(a[i], a[j]))
                    return false;
            }

        return true;
    }

    static double epsilon = 0.003;
    static double epsilon1 = 0.003;

    public struct Tacka
{
    public double x;
    public double y;
    public static bool operator ==(Tacka t,Tacka other){
    	return t.x==other.x&&t.y==other.y;
    }
     public static bool operator !=(Tacka t,Tacka other){
    	return !(t==other);
    }
};

public struct Figurica
{
    public Tacka teziste;
    public double angle;
};

static bool onSegment(Tacka p, Tacka q, Tacka r)
{
    if (q.x <= (double) Mathf.Max( (float) p.x, (float) r.x) && q.x >= (double) Mathf.Min((float) p.x, (float) r.x) &&
        q.y <= (double) Mathf.Max((float) p.y, (float) r.y) && q.y >= (double) Mathf.Min((float) p.y, (float) r.y))
        return true;
    return false;
}

static int orientation(Tacka p, Tacka q, Tacka r)
{
    double val = (q.y - p.y) * (r.x - q.x) -
              (q.x - p.x) * (r.y - q.y);

    if ((val > - epsilon)&&(val< epsilon)) return 0;

    return (val > 0) ? 1 : 2;
}
static bool presekDuzi(Tacka p1, Tacka q1, Tacka p2, Tacka q2)
{
    int o1 = orientation(p1, q1, p2);
    int o2 = orientation(p1, q1, q2);
    int o3 = orientation(p2, q2, p1);
    int o4 = orientation(p2, q2, q1);

    if (o1 == 0 || o2 == 0 || o3 == 0 || o4 == 0)
        return false;
    if (o1 != o2 && o3 != o4)
        return true;

    return false;
}
static bool B(Tacka A,Tacka B, Tacka C){
	return onSegment(A,B,C);
}
static bool B(Tacka A,Tacka B,Tacka C,Tacka D){
	return onSegment(A,B,C)&&onSegment(B,C,D);
}
static bool Collinear(Tacka A,Tacka B,Tacka C){

	return onSegment(A,B,C)||onSegment(B,A,C)||onSegment(B,C,A);
}
static bool DodirDuzi(Tacka p1, Tacka q1, Tacka p2, Tacka q2){

	if(p1==p2&&q1==q2)return true;
	if(p1==q2&&q1==p2)return true;
	if(onSegment(p1,p2,q1))
{
    if(onSegment(p1,q2,q1)||(onSegment(p2,p1,q2) && ((p2!=p1)||(!onSegment(q1,p2,q2))))||(onSegment(p2,q1,q2) && ((p2!=q1)||(!onSegment(p1,p2,q2)))))
	return true;
}

if(onSegment(p1,q2,q1))
{
    if(onSegment(p1,p2,q1)||(onSegment(p2,p1,q2) && ((q2!=p1)||(!onSegment(q1,q2,p2))))||(onSegment(p2,q1,q2) && ((q2!=q1)||(!onSegment(p1,q2,p2)))))
	return true;
}

if(onSegment(p2,p1,q2))
{
    if(onSegment(p2,q1,q2)||(onSegment(p1,p2,q1) && ((p1!=p2)||(!onSegment(q2,p1,q1))))||(onSegment(p1,q2,q1) && ((p1!=q2)||(!onSegment(p2,p1,q1)))))
	return true;
}

if(onSegment(p2,q1,q2))
{
    if(onSegment(p2,p1,q2)||(onSegment(p1,p2,q1) && ((q1!=p2)||(!onSegment(q2,q1,p1))))||(onSegment(p1,q2,q1) && ((q1!=q2)||(!onSegment(p2,q1,p1)))))
	return true;
}

return false;
/*
if(!Collinear(p1,q1,p2)||!Collinear(q1,p2,q2))return false;

	if(p1==q2)return !B(q1,p1,p2);


	if(p1==p2)return !B(q2,p1,q1);
	if(q1==q2)return !B(p1,q1,p2);
	if(q1==p2)return !B(p1,p2,q2);

	return !(B(p1,q1,p2,q2)||B(p1,q1,q2,p2)||B(q1,p1,p2,q2)||B(q1,p1,q2,p2));
*/	

	

}



static bool presekFigurica(Figurica f1, Figurica f2)
{


	int[] arr1 = new[] {0,0,1,1,1,0};
	int[] arr2 = new[] {0,0,0,0,1,1};
	int[] arr3 = new[] {1,0,0,0,0,1};
	int[] arr4 = new[] {1,0,0,0,0,1};
	int[] arr5 = new[] {1,1,0,0,0,0};
	int[] arr6 = new[] {0,1,1,1,0,0};

	int[][] NotGood = new[] { arr1, arr2, arr3 ,arr4,arr5,arr6};


    double x1 = f1.teziste.x, y1 = f1.teziste.y, angle1 = f1.angle;
    double x2 = f2.teziste.x, y2 = f2.teziste.y, angle2 = f2.angle;
    //double tackex1[6], tackey1[6], tackex2[6], tackey2[6];


    Tacka[] t1 = new Tacka[6];
    Tacka[] t2 = new Tacka[6];

        double k = Mathf.Sqrt(2);

    t1[0].x = x1 - (5.0 / 6.0) * Mathf.Cos((float) angle1)*k;
    t1[0].y = y1 - (5.0 / 6.0) * Mathf.Sin((float) angle1)*k;
    t1[3].x = x1 + (1.0 / 6.0) * Mathf.Cos((float) angle1)*k;
    t1[3].y = y1 + (1.0 / 6.0) * Mathf.Sin((float) angle1)*k;
    t1[1].x = t1[0].x + 2.0 * Mathf.Cos((float) angle1 + Mathf.Atan(1));
    t1[1].y = t1[0].y + 2.0 * Mathf.Sin((float) angle1 + Mathf.Atan(1));
    t1[5].x = t1[0].x + 2.0 * Mathf.Cos((float) angle1 - Mathf.Atan(1));
    t1[5].y = t1[0].y + 2.0 * Mathf.Sin((float) angle1 - Mathf.Atan(1));
    t1[2].x = t1[3].x + Mathf.Cos((float) angle1 + Mathf.Atan(1));
    t1[2].y = t1[3].y + Mathf.Sin((float) angle1 + Mathf.Atan(1));
    t1[4].x = t1[3].x + Mathf.Cos((float) angle1 - Mathf.Atan(1));
    t1[4].y = t1[3].y + Mathf.Sin((float) angle1 - Mathf.Atan(1));

    t2[0].x = x2 - (5.0 / 6.0) * Mathf.Cos((float) angle2)*k;
    t2[0].y = y2 - (5.0 / 6.0) * Mathf.Sin((float) angle2)*k;
    t2[3].x = x2 + (1.0 / 6.0) * Mathf.Cos((float) angle2)*k;
    t2[3].y = y2 + (1.0 / 6.0) * Mathf.Sin((float) angle2)*k;
    t2[1].x = t2[0].x + 2.0 * Mathf.Cos((float) angle2 + Mathf.Atan(1));
    t2[1].y = t2[0].y + 2.0 * Mathf.Sin((float) angle2 + Mathf.Atan(1));
    t2[5].x = t2[0].x + 2.0 * Mathf.Cos((float) angle2 - Mathf.Atan(1));
    t2[5].y = t2[0].y + 2.0 * Mathf.Sin((float) angle2 - Mathf.Atan(1));
    t2[2].x = t2[3].x + Mathf.Cos((float) angle2 + Mathf.Atan(1));
    t2[2].y = t2[3].y + Mathf.Sin((float) angle2 + Mathf.Atan(1));
    t2[4].x = t2[3].x + Mathf.Cos((float) angle2 - Mathf.Atan(1));
    t2[4].y = t2[3].y + Mathf.Sin((float) angle2 - Mathf.Atan(1));

    bool [] levi=new bool[6];
    bool [] desni=new bool[6];
    for (int i = 0; i < 6; i++)
    {
        for (int j = 0; j < 6; j++)
        {	if(DodirDuzi(t1[i], t1[(i + 1) % 6], t2[j], t2[(j + 1) % 6])){
        			levi[i]=true;
        			desni[j]=true;
       		 }
            if (presekDuzi(t1[i], t1[(i + 1) % 6], t2[j], t2[(j + 1) % 6])) return true;
        }
    }
    for(int i=0;i<6;i++){
    	for(int j=0;j<6;j++){
    		if(levi[i]&&levi[j]&&NotGood[i][j]==1)return true;
    		if(desni[i]&&desni[j]&&NotGood[i][j]==1)return true;
    	}
    }
    return false;
}

static bool prelaziGranicu(double a, Figurica f1)
{
    double x1 = f1.teziste.x, y1 = f1.teziste.y, angle1 = f1.angle;
    a = a/2;
    Tacka[] t1 = new Tacka[6];

    double k= Mathf.Sqrt(2);
        t1[0].x = x1 - (5.0 / 6.0) * Mathf.Cos((float)angle1) * k;
        t1[0].y = y1 - (5.0 / 6.0) * Mathf.Sin((float)angle1) * k;
        t1[3].x = x1 + (1.0 / 6.0) * Mathf.Cos((float)angle1) * k;
        t1[3].y = y1 + (1.0 / 6.0) * Mathf.Sin((float)angle1) * k;
        t1[1].x = t1[0].x + 2.0 * Mathf.Cos((float)angle1 + Mathf.Atan(1));
        t1[1].y = t1[0].y + 2.0 * Mathf.Sin((float)angle1 + Mathf.Atan(1));
        t1[5].x = t1[0].x + 2.0 * Mathf.Cos((float)angle1 - Mathf.Atan(1));
        t1[5].y = t1[0].y + 2.0 * Mathf.Sin((float)angle1 - Mathf.Atan(1));
        t1[2].x = t1[3].x + Mathf.Cos((float)angle1 + Mathf.Atan(1));
        t1[2].y = t1[3].y + Mathf.Sin((float)angle1 + Mathf.Atan(1));
        t1[4].x = t1[3].x + Mathf.Cos((float)angle1 - Mathf.Atan(1));
        t1[4].y = t1[3].y + Mathf.Sin((float)angle1 - Mathf.Atan(1));

    Tacka[] t2 = new Tacka[4];
    t2[0].x = -a-epsilon1;
    t2[0].y = -a-epsilon1;
    t2[1].x = -a-epsilon1;
    t2[1].y = a+epsilon1;
    t2[2].x = a+epsilon1;
    t2[2].y = a+epsilon1;
    t2[3].x = a+epsilon1;
    t2[3].y = -a-epsilon1;
    for (int i = 0; i < 6; i++)
    {
        for (int j = 0; j < 4; j++)
        {
            if (presekDuzi(t1[i], t1[(i + 1) % 6], t2[j], t2[(j + 1) % 4])) return true;
        }
    }
    if (f1.teziste.x >= -a-epsilon1 && f1.teziste.x <= a+epsilon1 && f1.teziste.y >= -a-epsilon1 && f1.teziste.y <= a+epsilon1) return false;
    return false;
}

}
