using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GeneralManager : MonoBehaviour
{
    public float L = 0, R;
    public int steps = 35;
    public Generator gen;
    public float Mid;
    public void initBin()
    {
        gen.Randomizuj();
        R = gen.N * gen.cellSize;
        Binarna();
    }

    public void Binarna()
    {
        if (steps == 0)
        {
            print("DONE!");
            return;
        }
        Mid = (R + L) / 2;
        gen.shrink.end = Mid;
        gen.Generate();

    }
    public void Check()
    {
        StartCoroutine(CHECK());
    }
    public IEnumerator CHECK()
    {
        yield return new WaitForSeconds(1.9f);
        List<Transform> g = new List<Transform>();
        foreach (GameObject obj in gen.Ls)
        {
            g.Add(obj.transform);
        }

        if (AleksinaProvera.IsOk(g, gen.shrink.transform.localScale.z))
        {
            R = Mid;
        }
        else
        {
            L = Mid;
        }
        Binarna();

    }
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }
}
