using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class Generator : MonoBehaviour
{
    public float cellSize=4;
    public int N=5;
    public GameObject L;
    public Shrink shrink;
    public Transform container;
    public int Number = 6;
    public GeneralManager instance;
    public List<GameObject> Ls;


    public List<int> Del;
    public List<float> uglovi;


    public void Randomizuj()
    {
        List<int> all = new List<int>();
        for (int i = 0; i < N * N; i++)
        {
            all.Add(i);
        }
        Raspodela.shuffl(all, all.Count, 0, N * N - 1);
        //Raspodela.Shuffle(all);


        //Del = Raspodela.GetRandomElements(all, Number);

        Del.Clear();
        uglovi.Clear();

        foreach (GameObject l in Ls)
        {
            Destroy(l);
        }

        Ls.Clear();

        for (int i = 0; i < Number; i++)
        {
            Del.Add(all[i]);
            uglovi.Add(45 * (int)Random.Range(0, 9));
        }

        //Generate(Del, uglovi);


    }
    public void Generate()
    {
        foreach (GameObject l in Ls)
        {
            Destroy(l);
        }

        Ls.Clear();

        shrink.start = N * cellSize;
        shrink.Init();
        //instance.R = 2 * Number;
      
        float currentZ = (-shrink.transform.localScale.z+cellSize) / 2;
        

        int Ord = 0;
        int indeks = 0;
        for (int i = 0; i < N; i++)
        {  float currentX = (-shrink.transform.localScale.x+cellSize) / 2;
            for(int j = 0; j < N; j++)
            {
                if (Del.Contains(Ord)) {
                    GameObject obj = Instantiate(L);

                    obj.transform.rotation = new Quaternion(0, 0, 0, 0);
                    obj.transform.Rotate(new Vector3(0, uglovi[indeks], 0));
                    obj.transform.position = new Vector3(currentX, 1f, currentZ);
                    obj.transform.parent = container;

                    //obj.GetComponent<Rigidbody>().useGravity = true;
                    indeks++;

                    Ls.Add(obj);
                }
                Ord++;
                currentX += cellSize;
            }
            currentZ += cellSize;
        }

        shrink.On = true;
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
public static class Raspodela
{
    public static void Shuffle<T>(this IList<T> list)
    {
        int n = list.Count;
        while (n > 1)
        {
            n--;
            int k = UnityEngine.Random.Range(0, n+1);
            T value = list[k];
            list[k] = list[n];
            list[n] = value;
        }
    }

    public static List<T> GetRandomElements<T>(this IEnumerable<T> list, int elementsCount)
    {
        return list.OrderBy(arg => System.Guid.NewGuid()).Take(elementsCount).ToList();
    }



    public static void shuff(List <int> a, int p, int i, int k)
    {
        int r1, r2, r;
        int m, n, e = p, b1 = 0, b2 = 0, d, j, br;
        int []b= new int [i - p + 1];
        int []c= new int [k - i];
        r1 = Random.Range(0,2);
        if (r1 == 0)
            for (j = 0; j < i - p + 1; j++)
                b[j] = a[p + j];
        else
            for (j = 0; j < i - p + 1; j++)
                b[i - p - j] = a[p + j];
        r2 = Random.Range(0,2);
        if (r2 == 0)
            for (j = 0; j < k - i; j++)
                c[j] = a[j + i + 1];
        else
            for (j = 0; j < k - i; j++)
                c[k - i - 1 - j] = a[j + i + 1];
        m = i - p + 1;
        n = k - i;
        d = k - p + 1;
        while ((b1 != m) && (b2 != n))
        {
            r = Random.Range(0, 2);
            if (r == 0)
            {
                a[e] = b[b1];
                b1 += 1;
                e += 1;
            }
            else
            {
                a[e] = c[b2];
                b2 += 1;
                e += 1;
            }
        }
        if (e < p + d)
        {
            if (b1 < m)
                for (br = b1; br < m; br++)
                {
                    a[e] = b[br];
                    e += 1;
                }
            else
                for (br = b2; br < n; br++)
                {
                    a[e] = c[br];
                    e += 1;
                }
        }
        return;
    }

    public static void shuffl(List <int> a, int n, int p, int k)
    {
        if (n == 1)
            ;
        else
        {
            shuffl(a, n / 2, p, p + n / 2 - 1);
            shuffl(a, n - n / 2, p + n / 2, k);
            shuff(a, p, p + n / 2 - 1, k);
        }
        return;
    }
};